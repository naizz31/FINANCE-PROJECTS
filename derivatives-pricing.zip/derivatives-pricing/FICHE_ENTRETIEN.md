# Fiche d'entretien : les bases des dérivés

Fiche perso pour préparer l'entretien. Pas besoin de la mettre sur GitHub.

## En une phrase

J'ai codé Black-Scholes avec les grecques et la volatilité implicite, un arbre binomial européen et américain, le prix et la duration d'une obligation, le prix forward et la couverture par futures, et une version simple du modèle de taux de Hull-White. Je l'ai vérifié sur les exemples de mon résumé du Hull.

## Questions probables

**Pourquoi Black-Scholes fonctionne ?**
Il repose sur un argument de réplication : une option vendue couverte par Δ actions forme un portefeuille sans risque, qui doit rapporter le taux sans risque. Le seul paramètre non observable est la volatilité.

**C'est quoi la valorisation risque-neutre ?**
On se place dans un monde où tous les actifs rapportent le taux sans risque et on actualise à ce taux. Le prix est le même que dans le monde réel, car il repose sur la réplication et non sur les préférences des investisseurs.

**Comment marche l'arbre binomial ?**
À chaque pas, le cours monte d'un facteur u ou baisse de 1/u. On part de l'échéance et on remonte en actualisant avec la probabilité risque-neutre. Quand le nombre de pas augmente, le prix converge vers Black-Scholes : dans mon test, l'écart est de 0,002 à 1 000 pas.

**Pourquoi un put américain vaut plus qu'un put européen ?**
Parce qu'on peut l'exercer avant l'échéance. Un call américain sans dividende vaut un call européen : je l'ai vérifié dans l'arbre.

**C'est quoi la volatilité implicite ?**
La volatilité qu'il faut mettre dans Black-Scholes pour retrouver le prix observé sur le marché. Sur les actions, elle est plus élevée pour les strikes bas : c'est le skew, qui vient de l'effet de levier et de la peur des krachs. Il montre que Black-Scholes à volatilité constante n'est pas parfait.

**Les grecques, en deux phrases ?**
Delta : sensibilité au cours, sert à la couverture. Gamma : vitesse du delta, positif pour un acheteur d'option. Vega : sensibilité à la volatilité. Theta : l'érosion du temps, de signe opposé au gamma. Rho : sensibilité aux taux.

**Duration et convexité ?**
La duration est la sensibilité linéaire du prix aux taux, la convexité corrige pour les grands mouvements. Dans mon exemple, +1 % de taux fait baisser l'obligation de 4,33 % : la duration seule dit 4,45 %, avec la convexité on retrouve 4,33 %.

**Le prix forward, c'est une prévision ?**
Non, c'est le prix qui empêche tout arbitrage : F = S × e^((r − q) × T). Avec un indice à 8 000, r = 4 % et un dividende de 2 %, je trouve 8 161,6. Si le futures cote 8 400, il est trop cher : je le vends et j'achète les actions.

**Comment couvrir un portefeuille avec des futures ?**
N = β × V / valeur d'un contrat. Avec 5,05 M€, un bêta de 1,5 et un futures à 5 050 points (10 € par point), il faut vendre 150 contrats.

**C'est quoi Hull-White ?**
Un modèle du taux court : dr = (θ(t) − a·r) dt + σ dW. Le taux revient vers un niveau à la vitesse a, avec un bruit de volatilité σ, et θ(t) est choisi pour que le modèle redonne exactement la courbe des taux d'aujourd'hui. Dans mon code, je vérifie que la simulation redonne le prix du zéro-coupon 5 ans de la courbe : 0,8342 contre 0,8343.

**Pourquoi Hull-White ?**
Il redonne exactement la courbe observée, ce qu'un modèle à paramètres constants comme Vasicek ne fait pas. Il garde le retour à la moyenne, et il donne des formules fermées pour le prix des zéro-coupons.

**Les taux peuvent devenir négatifs ?**
Oui, c'est un modèle gaussien : dans ma simulation, 0,8 % des trajectoires sont négatives à 5 ans. C'était utile sur l'euro entre 2014 et 2022, mais c'est aussi une limite.

## Les limites à assumer

- Black-Scholes : une seule volatilité, pas de smile ni de skew.
- La duration suppose un déplacement parallèle de la courbe des taux.
- Hull-White : un seul facteur, donc tous les taux bougent ensemble (le « niveau » de l'ACP) et pas la pente. Volatilité constante.
- Je n'ai pas branché de vraies données de marché : les paramètres, y compris `a = 0,10` et `σ = 1 %` de Hull-White, sont des hypothèses de démonstration. En pratique, on les calibre sur des caps ou des swaptions.
